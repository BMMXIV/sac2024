Elkhart Lake V1.0
My Scalextric Slot Track layout for Road America.
By Strava 06/01/2012

Type: Tarmac Road Course
Length: 503 Meters
Difficulty: Easy

Change Log:
06/01/2012 Initial release
